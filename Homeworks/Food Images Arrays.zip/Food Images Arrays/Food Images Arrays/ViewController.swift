//
//  ViewController.swift
//  Food Images Arrays
//
//  Created by Andres Ariel Alvarez on 9/28/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var foodImage: UIImageView!
    
    var imageNumber = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func nextDish(_ sender: UIButton) {
        let imageFood = [
        "Burger",
        "pizza",
        "salad"
        ]
        if imageNumber < imageFood.count - 1 {
            foodImage.image = UIImage(named: imageFood[imageNumber])
            imageNumber += 1
        } else {
            imageNumber = 0
        }
        let imageName = imageFood[imageNumber]
        print("image name: \(imageName)")
        foodImage.image = UIImage(named: imageName)
        
    }
    
}

