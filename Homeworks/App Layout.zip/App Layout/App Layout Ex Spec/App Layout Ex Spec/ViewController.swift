//
//  ViewController.swift
//  App Layout Ex Spec
//
//  Created by Andres Ariel Alvarez on 9/21/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imageViewer: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

