//
//  ViewController.swift
//  MadLib
//
//  Created by Andres Ariel Alvarez on 9/28/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var bodyOrgan: UITextField!
    @IBOutlet var adjective1: UITextField!
    @IBOutlet var verb: UITextField!
    @IBOutlet var adjective2: UITextField!
    @IBOutlet var pluralNoun: UITextField!
    @IBOutlet var container: UITextField!
    @IBOutlet var adjective3: UITextField!
    @IBOutlet var number: UITextField!
    
    @IBOutlet var lblEnter: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
// connection final Label
    @IBAction func btnEnter(_ sender: UIButton) {
        lblEnter.text = "Many say that " + bodyOrgan.text! + " storming is " + adjective1.text! + " and does not " + verb.text! + ". However, when you have pulled together a " + adjective2.text! + " group of " + pluralNoun.text! + ", brought together in a " + container.text! + " that is " + adjective3.text! + ", you will yield " + number.text! + " more ideas."
    }

}

