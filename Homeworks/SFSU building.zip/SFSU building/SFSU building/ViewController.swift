//
//  ViewController.swift
//  SFSU building
//
//  Created by Andres Ariel Alvarez on 9/27/21.
//

import UIKit

class ViewController: UIViewController {
    //reference to the imageplaceholder
    @IBOutlet weak var imageNumber: UIImageView!
    var imageIndex = 0
    let imageNames = ["art","business","humanities","library","studentUnion"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let imageName = imageNames[0]
        print("image name: \(imageName)")
        // Do any additional setup after loading the view.
    }

    @IBAction func nextBuildingButton(_ sender: UIButton) {
        if imageIndex < imageNames.count-1 {
            imageIndex = imageIndex + 1
        } else {
            imageIndex = 0
        }
        let imageName = imageNames[imageIndex]
        print("image name: \(imageName)")
        imageNumber.image = UIImage(named: imageName)
    }
    
}

