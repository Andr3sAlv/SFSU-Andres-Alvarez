//
//  ViewController.swift
//  FamousQuotes
//
//  Created by Andres Ariel Alvarez on 9/27/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var messageLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonPressed(_ sender: UIButton) {
    if messageLabel.text == "Woman was God's second mistake."{
        messageLabel.text = "He who has a why to live can bear almost any how."
    } else if messageLabel.text == "He who has a why to live can bear almost any how." { 
        messageLabel.text = "That which does not kill us makes us stronger."
    } else {
        messageLabel.text = "Woman was God's second mistake."
    }
    
}
}
