//
//  ViewController.swift
//  FoodImageWithLoops-Andres-Alvarez
//
//  Created by Andres Ariel Alvarez on 10/6/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var nameTxtField: UITextField!
    
    @IBOutlet var recieptTextField: UILabel!
   //create arrays to hold dishnames and price
    
    let dishNames = [
    "Burger",
    "pizza",
    "salad",
    "steak",
    "pasta"
    ]

    let dishesPrice: [Double] = [19.99,12.99,15.99,23.99,18.99]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    var myIndex = 0

    @IBAction func orderDishButtonClicked(_ sender: Any) {
        //figure out the dish ordered
        let dishOrder = nameTxtField.text!
        for index in 0 ..< dishNames.count-1 {
            if dishOrder == dishNames[index] {
                let dishOrderPrice = dishesPrice[index]
                recieptTextField.text = "Price of \(dishOrder): $\(dishOrderPrice)"
            }
        }
    }
    
    
}

