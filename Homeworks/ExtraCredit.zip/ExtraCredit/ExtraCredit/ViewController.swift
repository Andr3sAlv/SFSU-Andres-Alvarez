//
//  ViewController.swift
//  ExtraCredit
//
//  Created by Andres Ariel Alvarez on 9/28/21.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var tipAmount: UITextField!
    @IBOutlet var priceLabel: UILabel!
    @IBOutlet var imageHolder: UIImageView!
    @IBOutlet var totalPayment: UILabel!
    var imageNumber = 0
    let imageFood = [
    "Burger",
    "pizza",
    "salad"
    ]
    let pizza = 19.99
    let salad = 12.99
    let burger = 15.99
    let foodPrice = [
    "🍕 Price: $19.99",
    "🥗 Price: $12.99",
    "🍔 Price: $15.99"
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    
    
    @IBAction func showNextDish(_ sender: UIButton) {

        if imageNumber < imageFood.count - 1 {
            imageHolder.image = UIImage(named: imageFood[imageNumber])
            priceLabel.text = foodPrice[imageNumber]
            imageNumber += 1
        } else {
            imageNumber = 0
            priceLabel.text = foodPrice[2]
        }
        let imageName = imageFood[imageNumber]
        print("image name: \(imageName)")
        imageHolder.image = UIImage(named: imageName)
    }
    

    
    @IBAction func completeOrder(_ sender: UIButton) {
        let tipValue = Double(tipAmount.text!)
        print(tipValue!)
        if imageHolder.image == UIImage(named: imageFood[0]) {
            var total = tipValue * pizza
            totalPayment.text = total
        }
     
        
    }
    
}

